const booksData = [];

module.exports = booksData;
